function getInfo(json) {

    var obj_json = JSON.parse(json);
    var counter = 1;
    var table = document.getElementById('items').getElementsByTagName('tbody')[0];
    for (var j = 0; j < obj_json.length; j++) {
        var obj = obj_json[j];
        for (var i = 0; i < obj.length; i++) {
            var min = obj[i][0];
            var max = obj[i][1];
            var count = obj[i][2];
            var section = obj[i][3];

            // add new row in popup table
            var new_row = table.insertRow(table.rows.length);
            var cell1 = new_row.insertCell(0);
            var cell2 = new_row.insertCell(1);
            var cell3 = new_row.insertCell(2);
            var cell4 = new_row.insertCell(3);

            var new_text1 = document.createTextNode(counter);
            cell1.appendChild(new_text1);

            var new_text2 = document.createTextNode(section);
            cell2.appendChild(new_text2);

            var new_text3 = document.createTextNode(min + " - " + max);
            cell3.appendChild(new_text3);
            
            var new_text4 = document.createTextNode(count);
            cell4.appendChild(new_text4);

            counter++;
        }

        if (j === 0) {
            var empty_row = table.insertRow(table.rows.length);
            var empty_cell1 = empty_row.insertCell(0);
            var empty_cell2 = empty_row.insertCell(1);
            var empty_cell3 = empty_row.insertCell(2);
            var empty_cell4 = empty_row.insertCell(3);
            empty_cell1.appendChild(document.createTextNode(""));
            empty_cell2.appendChild(document.createTextNode(""));
            empty_cell3.appendChild(document.createTextNode(""));
            empty_cell3.appendChild(document.createTextNode(""));
        }
    }
}

// once the DOM is ready 
window.addEventListener('DOMContentLoaded', function () {
    // query for the active tab
    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, {from: 'popup', subject: 'getInfo'}, getInfo);
    });
});