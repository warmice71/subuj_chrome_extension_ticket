console.log("-----------Hello Vivid-------------");
(async function () {
    const url = window.location.href;
    const splits = url.split("\/");
    const text = splits[splits.length - 1];
    const t_sp = text.split("?");
    const eventID = t_sp[t_sp.length - 1];
    const ticketResponse = await getTicketsData(eventID);
    if (ticketResponse.status) {
        const data = ticketResponse.data;
        const result = {
            eventID: eventID,
            id: data.global[0].eventId,
            venueID: data.global[0].venueId,
            listingCount: data.global[0].listingCount,
            ticketCount: data.global[0].ticketCount,
            min: data.global[0].lp,
            max: data.global[0].hp,
            seats: data.tickets
        }
        console.log(result);
        chrome.runtime.sendMessage({ status: true, data: result, type: 'vividseats' });
    } else {
        chrome.runtime.sendMessage({ status: false, type: 'vividseats' });
    }

})();


function getTicketsData(eventID) {
    return new Promise((resolve) => {
        var xhr = new XMLHttpRequest();
        xhr.withCredentials = true;
        xhr.addEventListener("readystatechange", function () {
            if (this.readyState === 4) {
                try {
                    if (this.status == 404) {
                        resolve({
                            status: false
                        })
                    } else {
                        resolve({
                            status: true,
                            data: JSON.parse(xhr.responseText)
                        })
                    }
                } catch (e) {
                    resolve({
                        status: false
                    })
                }

            }
        });

        xhr.open("GET", `https://www.vividseats.com/rest/v2/web/listings/${eventID}`);
        xhr.setRequestHeader("fansight-tab", sessionStorage.getItem('FanSight-Tab'));
        xhr.send();
    })

}