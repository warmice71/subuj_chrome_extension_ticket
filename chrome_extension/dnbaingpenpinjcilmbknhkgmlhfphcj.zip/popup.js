var app = angular.module('myApp', []);
app.controller('myCtrl', function ($scope, $interval, $http) {

    $scope.urlapi = "https:/eagleanalytix.com/api";
    // $scope.urlapi = "http://localhost:3000/api";
    $scope.siteType = '';
    $scope.checkingApi = true;
    $scope.showKeyBox = false;
    $scope.apiKey = '';
    $scope.apikeyErr = false;
    $scope.apiKeyErrMsg = '';
    $scope.loading = false;
    $scope.ticketError = false;
    $scope.showtable = false;
    $scope.ticketData = {};
    $scope.filtered_seats = [];
    $scope.shData = null;
    $scope.vsData = null;
    $scope.tmData = null;
    $scope.shLink = null;
    $scope.vsLink = null;
    $scope.tmLink = null;
    $scope.showShVsTicketsData = true;
    $scope.shvsLoading = false;
    $scope.sortMode = '';
    $scope.total_tickets = 0;
    $scope.eventID = '';

    // Event listener for AXS
    chrome.runtime.onMessage.addListener(function (message) {
        if (message.type == 'axs') {
            if (message.status) {
                var data = message.data;
                var eventInfo = message.eventInfo;
                $scope.ticketData = {
                    total: data.total,
                    primary: data.primary,
                    resale: data.resale,
                    seats: data.seats
                }
                $scope.filtered_seats = $scope.ticketData.seats;
                $scope.loading = false;
                $scope.showtable = true;
                $scope.calcTotalTickets();
                $scope.$apply();
                if ($scope.showShVsTicketsData) {
                    $scope.shvsLoading = true;
                    chrome.tabs.executeScript({
                        code: '(' + getEventInformation + ')();' //argument here is a string but function.toString() returns function's code
                    }, (results) => {
                        //get sh and vs data
                        console.log("result: ", results);
                        try {
                            if (results && results[0]) {
                                let data = results[0]
                                $http.post($scope.urlapi + '/extension/getShVsTicketData', { key: $scope.apiKey, eventDate: data.eventDate, eventName: data.eventName, city: data.city })
                                    .then(function (response) {
                                        let data = response.data;
                                        $scope.shvsLoading = false;
                                        $scope.shData = data.shTicketData;
                                        $scope.vsData = data.vsTicketData;
                                        $scope.shLink = data.shLink;
                                        $scope.vsLink = data.vsLink;
                                    })

                            }

                        } catch (error) {
                            console.log(error);
                        }

                    });
                }
                $http.post($scope.urlapi + '/extension/saveAxsEvent', { eventInfo: JSON.stringify(eventInfo), key: $scope.apiKey }).then(function (response) { })

            } else {
                $scope.showtable = false;
                $scope.loading = false;
                $scope.ticketError = true;
                $scope.$apply();
            }
        } else if (message.type == 'evenue') {
            if (message.status) {
                let data = message.data;
                console.log(data);
                $scope.ticketData = {
                    total: data.total,
                    seats: data.seats
                }
                $scope.filtered_seats = $scope.ticketData.seats;
                $scope.loading = false;
                $scope.showtable = true;
                $scope.calcTotalTickets();
                $scope.$apply();
                if ($scope.showShVsTicketsData) {
                    $scope.shvsLoading = true;
                    chrome.tabs.executeScript({
                        code: '(' + getEventInformation + ')();' //argument here is a string but function.toString() returns function's code
                    }, (results) => {
                        try {
                            if (results && results[0]) {
                                let data = results[0]
                                console.log(data);
                                $http.post($scope.urlapi + '/extension/getShVsTicketData', { key: $scope.apiKey, eventDate: data.eventDate, eventName: data.eventName, venueName: data.venueName, source: 'evenue' })
                                    .then(function (response) {
                                        let data = response.data;
                                        $scope.shvsLoading = false;
                                        $scope.shData = data.shTicketData;
                                        $scope.vsData = data.vsTicketData;
                                        $scope.shLink = data.shLink;
                                        $scope.vsLink = data.vsLink;
                                    })

                            }

                        } catch (error) {
                            console.log(error);
                        }

                    });
                }
            } else {
                $scope.showtable = false;
                $scope.loading = false;
                $scope.ticketError = true;
                $scope.$apply();
            }
        } else if (message.type == 'mpv') {
            if (message.status) {
                const data = message.data;
                const eventInfo = data.eventInfo;
                $scope.ticketData = {
                    global_data: data.global_data,
                    seats: data.seats
                }
                $scope.filtered_seats = $scope.ticketData.seats;
                $scope.loading = false;
                $scope.showtable = true;
                $scope.calcTotalTickets();
                $scope.$apply();
                if ($scope.showShVsTicketsData) {
                    $scope.shvsLoading = true;
                    $http.post($scope.urlapi + '/extension/getShVsTicketData', { key: $scope.apiKey, eventDate: eventInfo.eventDate, eventName: eventInfo.eventName, venueName: eventInfo.venueName, source: 'mpv' })
                        .then(function (response) {
                            let data = response.data;
                            $scope.shvsLoading = false;
                            $scope.shData = data.shTicketData;
                            $scope.vsData = data.vsTicketData;
                            $scope.shLink = data.shLink;
                            $scope.vsLink = data.vsLink;
                        })


                }
            } else {
                $scope.showtable = false;
                $scope.loading = false;
                $scope.ticketError = true;
                $scope.$apply();
            }
        } else if (message.type == 'vividseats') {
            if (message.status) {
                const data = message.data;
                $scope.ticketData = {
                    eventID: data.eventID,
                    id: data.id,
                    venueID: data.venueID,
                    listingCount: data.listingCount,
                    ticketCount: data.ticketCount,
                    min: data.min,
                    max: data.max,
                    seats: data.seats
                }
                $scope.filtered_seats = $scope.ticketData.seats;
                $scope.loading = false;
                $scope.showtable = true;
                $scope.calcTotalTickets();
                $scope.$apply();
                if ($scope.showShVsTicketsData) {
                    $scope.shvsLoading = true;
                    $http.post($scope.urlapi + '/extension/getShTmTicketData', { key: $scope.apiKey, vsEventID: $scope.ticketData.eventID, vsID: $scope.ticketData.id, venueID: $scope.ticketData.venueID })
                        .then(function (response) {
                            let data = response.data;
                            console.log(data);
                            $scope.shvsLoading = false;
                            if (data.status) {
                                $scope.shData = data.shTicketData;
                                $scope.tmData = data.tmTicketData;
                                $scope.shLink = data.shLink;
                                $scope.tmLink = data.tmLink;
                            }
                        })
                }
            } else {
                $scope.showtable = false;
                $scope.loading = false;
                $scope.ticketError = true;
                $scope.$apply();
            }
        }

    });



    $scope.checkApi = function () {
        $scope.checkingApi = true;
        chrome.storage.sync.get(['ticketdatamaster_extensionkeys'], function (result) {
            if (result && result.ticketdatamaster_extensionkeys) {
                const apikey = result.ticketdatamaster_extensionkeys;
                $scope.apiKey = apikey;
                $http.post($scope.urlapi + '/extension/checkKey', { key: apikey })
                    .then(function (response) {
                        let data = response.data;
                        $scope.checkingApi = false;
                        if (data.status) {
                            $scope.showKeyBox = false;
                            $scope.showShVsTicketsData = data.showShVsTicketsData;
                            $scope.checkSite_and_Tickets();
                        } else {
                            $scope.showKeyBox = true;
                            $scope.checkingApi = false;
                            $scope.$apply();
                        }
                    })
            } else {
                $scope.showKeyBox = true;
                $scope.checkingApi = false;
                $scope.$apply();
            }

        });
    }

    $scope.saveKey = function () {
        const apikey = $("#apiKey").val();
        $scope.apiKey = apikey;
        if (apikey != '') {
            $http.post($scope.urlapi + '/extension/checkKey', { key: apikey })
                .then(function (response) {
                    let data = response.data;
                    if (data.status) {
                        chrome.storage.sync.set({
                            ticketdatamaster_extensionkeys: apikey
                        }, function (res) { console.log(res); })
                        $scope.showKeyBox = false;
                        $scope.showShVsTicketsData = data.showShVsTicketsData;
                        $scope.checkSite_and_Tickets();
                    } else {
                        $scope.apikeyErr = true;
                        $scope.apiKeyErrMsg = data.message;
                    }
                })
        } else {
            $scope.apikeyErr = true;
            $scope.apiKeyErrMsg = 'Please input api key.';
        }
    }

    $scope.checkApi();

    $scope.changeShowShVsTicketsData = function () {
        $scope.showShVsTicketsData = !$scope.showShVsTicketsData;
        $http.post($scope.urlapi + '/extension/changeshowShVsTicketsData', { key: $scope.apiKey, showShVsTicketsData: $scope.showShVsTicketsData })
            .then(function (response) {
            })
        if ($scope.shData == null && $scope.showShVsTicketsData) {
            $scope.shvsLoading = true;
            if ($scope.siteType != 'mpv') {
                chrome.tabs.executeScript({
                    code: '(' + getEventInformation + ')();' //argument here is a string but function.toString() returns function's code
                }, (results) => {
                    //get sh and vs data
                    try {
                        if (results && results[0]) {
                            let data = results[0]
                            $http.post($scope.urlapi + '/extension/getShVsTicketData', { key: $scope.apiKey, eventDate: data.eventDate, eventName: data.eventName, city: data.city })
                                .then(function (response) {
                                    $scope.shvsLoading = false;
                                    let data = response.data;
                                    $scope.shData = data.shTicketData;
                                    $scope.vsData = data.vsTicketData;
                                    $scope.shLink = data.shLink;
                                    $scope.vsLink = data.vsLink;
                                })

                        }

                    } catch (error) {
                        console.log(error);
                        $scope.showtable = false;
                        $scope.ticketError = true;
                    }

                });
            }

        }
    }

    //check site
    $scope.checkSite_and_Tickets = function () {
        $scope.loading = true;
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, tabs => {
            let url = tabs[0].url;
            if (url.includes('ticketmaster') || url.includes('livenation')) {
                $scope.siteType = 'ticketmaster';
                $scope.tm_searchTickets(url);
            } else if (url.includes('axs.com')) {
                $scope.siteType = 'axs';
                chrome.tabs.executeScript(tabs[0].id, {
                    file: 'payload_axs.js'
                });
            } else if (url.includes('evenue.net')) {
                $scope.siteType = 'evenue';
                chrome.tabs.executeScript(tabs[0].id, {
                    file: 'payload_evenue.js'
                });
            } else if (url.includes('mpv.tickets.com')) {
                $scope.siteType = 'mpv';
                chrome.tabs.executeScript(tabs[0].id, {
                    file: 'payload_mpv.js'
                });
            } else if (url.includes('tickets.com/buy/TicketPurchase')) {
                $scope.siteType = 'tickets-purchase';
                $scope.showtable = true;
                $scope.loading = false;
                if ($scope.showShVsTicketsData) {
                    $scope.shvsLoading = true;
                    chrome.tabs.executeScript({
                        code: '(' + getEventInformation + ')();' //argument here is a string but function.toString() returns function's code
                    }, (results) => {
                        //get sh and vs data
                        try {
                            if (results && results[0]) {
                                let data = results[0]
                                $http.post($scope.urlapi + '/extension/getShVsTicketData', { key: $scope.apiKey, eventDate: data.eventDate, eventName: data.eventName, venueName: data.venueName, source: 'tickets-purchase' })
                                    .then(function (response) {
                                        let data = response.data;
                                        $scope.shvsLoading = false;
                                        $scope.shData = data.shTicketData;
                                        $scope.vsData = data.vsTicketData;
                                        $scope.shLink = data.shLink;
                                        $scope.vsLink = data.vsLink;
                                    })

                            }

                        } catch (error) {
                            console.log(error);
                            $scope.showtable = false;
                            $scope.ticketError = true;
                        }

                    });
                }
            } else if (url.includes('stubhub.com')) {
                $scope.siteType = 'stubhub';
                $scope.sh_searchTickets(url);
            } else if (url.includes('vividseats')) {
                $scope.siteType = 'vividseats';
                chrome.tabs.executeScript(tabs[0].id, {
                    file: 'payload_vividseats.js'
                });
            } else {
                $scope.showtable = false;
                $scope.loading = false;
                $scope.ticketError = true;
                $scope.$apply();
            }
        });
    }

    $scope.tm_searchTickets = function (url) {
        let sp_url = url.split('?');
        let eventID = sp_url[0];
        let eventIDSP = eventID.split('/');
        eventID = eventIDSP[eventIDSP.length - 1];
        eventIDSP = eventID.split('#');
        eventID = eventIDSP[0];
        $scope.eventID = eventID;

        if (eventID && eventID.length == 16) {
            $http.post($scope.urlapi + '/extension/getTmTickets', { key: $scope.apiKey, eventID: eventID })
                .then(function (response) {
                    let data = response.data;
                    $scope.loading = false;
                    if (data.status) {
                        $scope.ticketError = false;
                        $scope.showtable = true;
                        $scope.ticketData = data.ticketData;
                        $scope.filtered_seats = data.ticketData.seats;
                        $scope.calcTotalTickets();
                        $http.post($scope.urlapi + '/extension/saveToStore', { key: $scope.apiKey, eventID: eventID })
                    } else {
                        $scope.showtable = false;
                        $scope.ticketError = true;
                    }
                })
            if ($scope.showShVsTicketsData) {
                $scope.shvsLoading = true;
                chrome.tabs.executeScript({
                    code: '(' + getEventInformation + ')();' //argument here is a string but function.toString() returns function's code
                }, (results) => {
                    //get sh and vs data
                    try {
                        if (results && results[0]) {
                            let data = results[0]
                            $http.post($scope.urlapi + '/extension/getShVsTicketData', { key: $scope.apiKey, eventDate: data.eventDate, eventName: data.eventName, city: data.city })
                                .then(function (response) {
                                    let data = response.data;
                                    $scope.shvsLoading = false;
                                    $scope.shData = data.shTicketData;
                                    $scope.vsData = data.vsTicketData;
                                    $scope.shLink = data.shLink;
                                    $scope.vsLink = data.vsLink;
                                })

                        }

                    } catch (error) {
                        console.log(error);
                        $scope.showtable = false;
                        $scope.ticketError = true;
                    }

                });
            }
        } else {
            $scope.showtable = false;
            $scope.ticketError = true;
            $scope.loading = false;
            $scope.$apply();
        }
    }

    $scope.sh_searchTickets = function (url) {
        let sp_url = url.split('?');
        let eventID = sp_url[0];
        let eventIDSP = eventID.split('#');
        eventID = eventIDSP[0];
        eventIDSP = eventID.split('/');
        eventID = eventIDSP[eventIDSP.length - 2];
        $scope.eventID = eventID;
        $http.post($scope.urlapi + '/extension/getShTickets', { key: $scope.apiKey, eventID: eventID })
            .then(function (response) {
                let data = response.data;
                $scope.loading = false;
                if (data.status) {
                    $scope.ticketError = false;
                    $scope.showtable = true;
                    $scope.globalData = data.globalData;
                    $scope.ticketData = data.listings;
                    $scope.filtered_seats = data.listings;
                    $scope.calcTotalTickets();
                    $scope.shvsLoading = true;
                    $http.post($scope.urlapi + '/extension/getVsTmTicketData', { eventID: eventID })
                        .then(function (response) {
                            let data = response.data;
                            console.log(data);
                            $scope.shvsLoading = false;
                            $scope.tmData = data.tmTicketData;
                            $scope.vsData = data.vsTicketData;
                            $scope.tmLink = data.tmLink;
                            $scope.vsLink = data.vsLink;
                        })
                } else {
                    $scope.showtable = false;
                    $scope.ticketError = true;
                }
            })
    }

    $scope.filterSeats = function () {
        const keyword = $('#filter_keyword').val();
        if ($scope.siteType == 'stubhub') {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.filter(v => v.sectionName.toLowerCase().includes(keyword.toLowerCase()))
            } else {
                $scope.filtered_seats = $scope.ticketData
            }
        } else if ($scope.siteType == 'vividseats') {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.seats.filter(v => v.s.toLowerCase().includes(keyword.toLowerCase()))
            } else {
                $scope.filtered_seats = $scope.ticketData.seats
            }
        } else {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.seats.filter(v => v.section.toLowerCase().includes(keyword.toLowerCase()))
            } else {
                $scope.filtered_seats = $scope.ticketData.seats
            }
        }

        $scope.calcTotalTickets();
    }

    $scope.filterSeatsByPrice = function () {
        const keyword = $('#filter_keyword_price').val();
        if ($scope.siteType == 'mpv') {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.seats.filter(v => v.price == parseFloat(keyword))
            } else {
                $scope.filtered_seats = $scope.ticketData.seats
            }
        } else if ($scope.siteType == 'stubhub') {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.filter(v => v.listingPrice.amount == parseFloat(keyword))
            } else {
                $scope.filtered_seats = $scope.ticketData
            }
        } else if ($scope.siteType == 'vividseats') {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.seats.filter(v => parseFloat(v.p) == parseFloat(keyword))
            } else {
                $scope.filtered_seats = $scope.ticketData.seats
            }
        } else {
            if (keyword) {
                $scope.filtered_seats = $scope.ticketData.seats.filter(v => v.min == parseFloat(keyword))
            } else {
                $scope.filtered_seats = $scope.ticketData.seats
            }
        }


        $scope.calcTotalTickets();
    }

    $scope.sortBy = function (sortItem, sortItem2 = null) {
        if (sortItem && !sortItem2) {
            if ($scope.sortMode == 'up') {
                $scope.sortMode = 'down';
                $scope.filtered_seats = $scope.filtered_seats.sort((a, b) => { if (b[sortItem] < a[sortItem]) return 1; if (b[sortItem] > a[sortItem]) return -1; return 0 });
            } else {
                $scope.sortMode = 'up';
                $scope.filtered_seats = $scope.filtered_seats.sort((a, b) => { if (b[sortItem] > a[sortItem]) return 1; if (b[sortItem] < a[sortItem]) return -1; return 0 });
            }
        }
        if (sortItem && sortItem2) {
            if ($scope.sortMode == 'up') {
                $scope.sortMode = 'down';
                $scope.filtered_seats = $scope.filtered_seats.sort((a, b) => { if (b[sortItem][sortItem2] < a[sortItem][sortItem2]) return 1; if (b[sortItem][sortItem2] > a[sortItem][sortItem2]) return -1; return 0 });
            } else {
                $scope.sortMode = 'up';
                $scope.filtered_seats = $scope.filtered_seats.sort((a, b) => { if (b[sortItem][sortItem2] > a[sortItem][sortItem2]) return 1; if (b[sortItem][sortItem2] < a[sortItem][sortItem2]) return -1; return 0 });
            }
        }
    }

    $scope.calcTotalTickets = function () {
        let t = 0;
        if ($scope.siteType == 'stubhub') {
            for (let i = 0; i < $scope.filtered_seats.length; i++) {
                t = t + $scope.filtered_seats[i].quantity;
            }
        } else if ($scope.siteType == 'vividseats') {
            for (let i = 0; i < $scope.filtered_seats.length; i++) {
                t = t + parseFloat($scope.filtered_seats[i].q);
            }
        } else {
            for (let i = 0; i < $scope.filtered_seats.length; i++) {
                t = t + $scope.filtered_seats[i].count;
            }
        }
        $scope.total_tickets = t;
    }


});

function getEventInformation() {
    let url = location.href;
    if (url.includes('ticketmaster') || url.includes('livenation')) {
        try {
            const dateString = document.querySelector(".event-header__event-date").innerText;
            const eventName = document.querySelector(".event-header__event-name-text").innerText;
            const venue = document.querySelector(".event-header__event-location").innerText;
            const venue_sp = venue.split(',');
            const city = venue_sp[1].trim();
            return {
                eventDate: dateString,
                eventName: eventName,
                city: city
            }
        } catch (error) {
            return null;
        }
    } else if (url.includes('axs.com')) {
        try {
            const dateString = document.querySelector(".event-header-date").innerText;
            const eventName = document.querySelector(".event-summary-headline__event").innerText;
            let venue = '';
            if (document.querySelector('.venue')) {
                venue = document.querySelector('.venue').innerText;
            } else if (document.querySelector(".event-summary-headline__bottom-title")) {
                venue = document.querySelector(".event-summary-headline__bottom-title").innerText;
            }
            if (venue == '') return null;
            const venue_sp = venue.split(',');
            const city = venue_sp[1].trim();
            return {
                eventDate: dateString,
                eventName: eventName,
                city: city
            }
        } catch (error) {
            console.log(error);
            return null;
        }
    } else if (url.includes('evenue.net')) {
        try {
            document.querySelector("#ev_date").innerHTML = document.querySelector("#ev_date").innerHTML.replace(/\&nbsp;/g, ' ');
            let eventDate = document.querySelector("#ev_date").innerText;
            let eventName = document.querySelector("#ev_description").innerText;
            let venue = document.querySelector('#ev_facility').innerText;
            eventDate = eventDate.replace("Event Date: ", "");
            eventDate = eventDate.replace(' at ', ' ');
            eventDate = eventDate.replace(' pm', ' PM');
            venue = venue.replace("Facility: ", "");
            console.log(eventDate)
            let data = {
                eventDate: new Date(eventDate).toLocaleString(),
                eventName: eventName,
                venueName: venue
            };
            console.log(data);
            return data;
        } catch (error) {
            console.log(error);
            return null;
        }
    } else if (url.includes('tickets.com/buy/TicketPurchase')) {
        try {
            const eventName = document.querySelector('#availability_left_column h2').textContent;
            var eventDate = document.querySelector('.time').textContent;
            eventDate = eventDate.replace('2021', '2021 ').replace('2022', '2022 ').replace('2023', '2023 ').replace('AM', ' AM').replace('PM', ' PM');
            const venue = document.querySelector('.venue span').textContent;
            const data = {
                eventName: eventName,
                eventDate: eventDate,
                venueName: venue
            }
            console.log(data);
            return data;
        } catch (error) {
            console.log(error);
            return null;
        }
    }



}