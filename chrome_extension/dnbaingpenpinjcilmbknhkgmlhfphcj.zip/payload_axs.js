console.log("-----------Hello-------------");
(async function () {
    let url = window.location.href;
    var splits = url.split("\/");
    let onsaleID = splits[3];
    let sectionResponse = await getSectionData(onsaleID);
    let priceResponse = await getPriceData(onsaleID);
    if (sectionResponse.status) {
        let eventResponse = await getEventData(onsaleID);
        const eventInfo = filterEventInfo(url, onsaleID, eventResponse.data.onsaleInformation)
        let pricesData = priceResponse.data;
        let primary = 0, resale = 0;
        let seatsData = [];
        for (let [key, value] of Object.entries(sectionResponse.data)) {
            if (value.seatTypes[0] == 'STANDARD') primary += value.availability.total; else resale += value.availability.total;
            let item = {
                type: value.seatTypes.join(),
                count: value.availability.total,
                section: value.sectionLabel,
                min: '',
            }
            if (value.availability.prices.length > 0) {
                let priceID = value.availability.prices[0].priceLevel;
                let price = '';
                if (pricesData && pricesData.offerPrices) {
                    for (let k = 0; k < pricesData.offerPrices.length; k++) {
                        for (let z = 0; z < pricesData.offerPrices[k].zonePrices.length; z++) {
                            for (let p = 0; p < pricesData.offerPrices[k].zonePrices[z].priceLevels.length; p++) {
                                let priceItem = pricesData.offerPrices[k].zonePrices[z].priceLevels[p];
                                if (priceItem.priceLevelID == priceID) {
                                    price = priceItem.prices[0].base / 100
                                }
                            }
                        }
                    }
                    item.min = price;
                }
            }
            seatsData.push(item);
        }
        let result = {
            total: primary + resale,
            primary: primary,
            resale: resale,
            seats: seatsData
        }
        chrome.runtime.sendMessage({ status: true, data: result, eventInfo: eventInfo, type: 'axs' });
    } else {
        chrome.runtime.sendMessage({ status: false, type: 'axs' });
    }

})();


function getSectionData(onsaleID) {
    return new Promise((resolve) => {
        var xhr = new XMLHttpRequest();
        xhr.withCredentials = true;
        xhr.addEventListener("readystatechange", function () {
            if (this.readyState === 4) {
                try {
                    if (this.status == 404) {
                        resolve({
                            status: false
                        })
                    } else {
                        resolve({
                            status: true,
                            data: JSON.parse(xhr.responseText)
                        })
                    }
                } catch (e) {
                    resolve({
                        status: false
                    })
                }

            }
        });

        xhr.open("GET", "https://unifiedapicommerce.us-prod0.axs.com/veritix/inventory/V2/" + onsaleID + "/sections");
        xhr.setRequestHeader("fansight-tab", sessionStorage.getItem('FanSight-Tab'));
        xhr.send();
    })

}

function getPriceData(onsaleID) {
    return new Promise((resolve) => {
        var xhr = new XMLHttpRequest();
        xhr.withCredentials = true;
        xhr.addEventListener("readystatechange", function () {
            if (this.readyState === 4) {
                try {
                    if (this.status == 404) {
                        resolve({
                            status: false
                        })
                    } else {
                        resolve({
                            status: true,
                            data: JSON.parse(xhr.responseText)
                        })
                    }
                } catch (e) {
                    resolve({
                        status: false
                    })
                }

            }
        });

        xhr.open("GET", `https://unifiedapicommerce.us-prod0.axs.com/veritix/inventory/v2/${onsaleID}/price?locale=en-US&getSections=true&grouped=true&includeSoldOuts=false&includeDynamicPrice=true`);
        xhr.setRequestHeader("fansight-tab", sessionStorage.getItem('FanSight-Tab'));
        xhr.send();
    })

}

function getEventData(onsaleID) {
    return new Promise((resolve) => {
        var xhr = new XMLHttpRequest();
        xhr.withCredentials = true;
        xhr.addEventListener("readystatechange", function () {
            if (this.readyState === 4) {
                try {
                    if (this.status == 404) {
                        resolve({
                            status: false
                        })
                    } else {
                        resolve({
                            status: true,
                            data: JSON.parse(xhr.responseText)
                        })
                    }
                } catch (e) {
                    resolve({
                        status: false
                    })
                }

            }
        });

        xhr.open("GET", `https://unifiedapicommerce.us-prod0.axs.com/veritix/onsale/v2/${onsaleID}?locale=en-US`);
        xhr.setRequestHeader("fansight-tab", sessionStorage.getItem('FanSight-Tab'));
        xhr.send();
    })
}

function filterEventInfo(eventUrl, onsaleID, salesInformation) {
    try {
        let eventInfo = {
            url: eventUrl,
            onsaleID: onsaleID,
            eventID: salesInformation.events[0].eventID,
            name: salesInformation.title,
            sale: {
                startDate: salesInformation.startDate,
                endDate: salesInformation.endDate
            },
            date: salesInformation.events[0].date,
            venue: salesInformation.venues[0]
            // mapImage: salesInformation.groups[0].venueMapImage
        }
        return eventInfo;
    } catch (e) {
        return null;
    }
}