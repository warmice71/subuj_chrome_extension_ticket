(async () => {
    return window.getSelection().toString().trim();
})();

